"""
XAI package for skin lesion classification with explainable AI.
"""

__version__ = "0.1.0"
